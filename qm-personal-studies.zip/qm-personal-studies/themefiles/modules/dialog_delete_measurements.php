<div class="dialog-background transitions" id="deletemeasurement-dialog-background"></div>
<div class="deletemeasurement-dialog transitions" id="deletemeasurement-dialog">
	<div class="loading-overlay" id="deletemeasurement-loading"></div>
	<div class="deletemeasurement-header" id="deletemeasurement-dialog-header">
		<div class="dialog-header">
			Delete the Measurements
		</div>
	</div>
	<div class="deletemeasurement-content" id="deletemeasurement-dialog-content">
		<table>
			<tr>
				<td>Are you sure you want to delete all measurements for this variable?</td>				
			</tr>
			<tr>				
				<td>This cannot be undone.</td>
			</tr>
		</table>
		
		<button id="button-dodelete" class="button-cancel buttonrow-2">Yes</button>
		<button  id="button-canceldelete" class="button-save buttonrow-2">No</button>
	
	</div>
</div>