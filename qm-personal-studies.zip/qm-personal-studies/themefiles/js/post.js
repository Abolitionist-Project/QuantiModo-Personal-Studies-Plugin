$(".update-chart").each( function() {
    alert("Your book is overdue.");
});