jQuery(document).ready(function($) {
	// $('select').select2({
	// 	width: 'off',
	// 	allowClear: true,
	// });
});